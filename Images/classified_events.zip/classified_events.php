<?php
require_once "maincore.php";
require_once THEMES."templates/header.php";
?>
<style>
	body {
		background-color: #fff !important;
	}
	.classified-events-main {
		position: relative;
		display: table;
		width: 80%;
		height: auto;
		margin: 50px auto;
	}
	.cem-center-line {
		position: absolute;
		right: 0;
		left: 0;
		margin: 0 auto;
		width: 1px;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.09);
		
	}
	.cem-sub {
		position: relative;
		display: inline-table;
		right: 0;
		height: auto;
		width: 100%;
		margin: 30px 0;
	}
	.cem-sub:nth-child(odd) .cems-p, .cem-sub:nth-child(odd) .cems-date  {
		float: right;
	}
	.cem-sub:nth-child(even) .cems-p, .cem-sub:nth-child(even) .cems-date  {
		float: left;
	}
	.cems-p {
		position: relative;
		width: calc(50% - 110px);
		padding: 30px;
		font-size: 14px;
		line-height: 22px;
		box-shadow: 0 2px 3px rgba(0, 0, 0, 0.05);
		color: #535353 !important;
	}
	.cems-icon {
		position: absolute;
		right: 0;
		left: 0;
		top: 0;
		bottom: 0;
		margin: auto auto;
		width: 50px;
		height: 50px;
		border-radius: 100%;
		background-color: #E5E5E5;
		transition: 0.3s cubic-bezier(.9,.03,.69,.22);
	}
	.cems-icon:hover, .cems-date:hover ~ .cems-icon, .cems-p:hover ~ .cems-icon { 
		background-color: #cd2122;
	}
	.cems-date {
		position: relative;
		padding: 5px 10px;
		font-weight: 700;
		font-size: 13px;
		border-radius: 2px;
		white-space: nowrap;
		color: #787878;
		margin: 0 100px;
		box-shadow: 0 2px 3px rgba(0, 0, 0, 0.05);
	}
	@media only screen and (max-width: 900px) {
		.cem-sub {
			margin: 50px 0;
		}
		.cems-date {
			position: absolute;
			top: -26px;
			margin: 0 auto;
			right: 0;
			left: 0;
			width: auto;
			max-width: 175px;
			text-align: center;
			min-width: 40px;
			background-color: #fff;
		}
		.cems-p {
			width: calc(100% - 60px);
			background-color: #fff;
		}
		.cems-icon {
			display: none;
		}
	}
</style>
<section style="background-color: #fff;" class="classified-events-main">
	<div class="cem-center-line">
		
	</div>
	<?php
		$q = dbquery("SELECT * FROM ".DB_NEWS." ORDER BY news_id DESC");
		while($data=dbarray($q)){
			echo 
			'<div class="cem-sub">
				<div class="cems-p">
				'.$data['news_news'].'
				</div>
				<div class="cems-date">
					'.jdate("Y F",$data['news_datestamp']).'
				</div>
				<div class="cems-icon">
					
				</div>
			</div>';
		}
		echo 
		"<script>
			$(document).ready(function() {
				$('body').attr('onresize', 'classilo()');
			});
			document.onload = classilo();
			function classilo() {
				if(parseInt($('html').css('width')) > 900) {
					for(var i=1; i <= $('.cem-sub').length+1; i++) {
						$('.cem-sub:nth-child('+i+') .cems-date').css('top', (parseInt($('.cem-sub:nth-child('+i+')').css('height'))/2-14));
					}
				} else {
					$('.cems-date').css('top', '0');
				}
			}
		</script>";
	?>
	
	
</section>


<?php
require_once THEMES."templates/footer.php";
?>